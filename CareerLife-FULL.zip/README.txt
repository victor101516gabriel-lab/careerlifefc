CAREERLIFE FC — VERSÃO COMPLETA FRONT-END

1. Abra index.html para testar.
2. Para publicar, envie index.html para uma hospedagem de site estático.
3. O progresso é salvo no navegador (localStorage).
4. Exportar/Importar permite levar o save para outro navegador.

Esta versão é funcional e foi criada para ser uma base de jogo. Recursos que exigem servidor (login, multiplayer, banco de dados online e sincronização entre dispositivos) precisam de backend numa próxima etapa.
